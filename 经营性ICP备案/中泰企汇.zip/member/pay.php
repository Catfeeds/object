﻿<?php
?>
<html>
	<head>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-compatible" content="IE=edge,chrome=1" />
    <title>支付_北京中泰企汇金融服务外包有限公司</title>
	
	
	</head>
	<body id="register">
		<div id="top">
			<div class="center" >
				<div class="left">
					<div class="logo">
						<a href="/"><img src="images/pay_newlogo.png" style="margin: 15px auto;"/><!-- <img src="images/slgen.png" /> --></a>
					</div>
				</div>
				<!-- <div class="middle">
					<span></span>
				</div> -->
				<div class="right">
					<a href="/" class="my">返回首页</a>
					<!-- <a href="" class="app">APP下载</a> -->
				</div>
			</div>
		</div>
		
		
		
		
		<div align="center" style="text-align:left; width:600px; margin-left:auto; margin-right:auto;">




<div class="content_registw" style="margin-bottom: 60px; background:#FFFFFF; margin-top:20px; padding:20px">
	<div class="registContainer">
		
		<div id="content" class="w960 clearfix">
 <div class="panel panel-default basic">
  <div class="panel-headingw"></div>
  <div class="panel-bodyw">
		<form action="#" method="post" novalidate class="bv-form">
		
		
		欢迎您：<span style="color:green"><?php echo $_SESSION['name']; ?></span>
		<div class="row" style="padding:15px">
			<div class="col-xs-4">
				支付金额:
			</div>
			<div class="col-xs-8">
			  <input type="text" name="cash" value="1000" class="regist_input">
			</div>
		</div>
		<div class="row" style="padding:15px">
			<div class="col-xs-4">
				支持银行: 
			</div>
			<div class="col-xs-6">
				<select name="bank" class="regist_input">
					<option value="1">工商银行</option>
					<option value="2">农业银行</option>
					<option value="3">中国银行</option>
					<option value="4">建设银行</option>
					<option value="5">交通银行</option>
					<option value="6">招商银行</option>
					<option value="7">浦发银行</option>
					<option value="8">民生银行</option>
				</select>
			</div>
		</div>
		
		<div class="row" style="padding:15px">
			<div class="col-xs-4">
				银行图示: 
			</div>
			<div class="col-xs-6">
				<img src="bank_list.png" width="550">
			</div>
		</div>
		
		<div class="row">
			
			
		</div>
		
		<script type="text/javascript">
function check(){
 alert("提交成功，我们会尽快与您联系!");
}
</script>


		<div class="row" style="padding:15px">
							<input value="立即支付" class="btn_input" type="submit" onClick="return check();"> 
		</div>
		</form>
  </div>
  
</div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
		
		
		
	</div>
</div>






</div>
		<!-- <div id="partner">
			<span></span>
				<i></i>
		</div> -->
		<div id="foot">
			<div class="center">
			  <div class="bottom">
					<ul>
						<li>版权所有:北京中泰企汇金融服务外包有限公司&nbsp;&nbsp;地址：北京市西城区西直门外大街甲143号1-5-4002室&nbsp;&nbsp;电话：010-68368590&nbsp;&nbsp;备案号：<a href="http://www.miitbeian.gov.cn" target="_blank"></a> </li>
					</ul>
				
				</div>
			</div>
		</div>
	</body>
</html>